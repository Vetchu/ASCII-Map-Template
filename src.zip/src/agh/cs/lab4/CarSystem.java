package agh.cs.lab4;

public class CarSystem {
    public static void main(String[] args) {

    }
}
