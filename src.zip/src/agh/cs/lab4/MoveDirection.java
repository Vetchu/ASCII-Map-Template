package agh.cs.lab4;

enum MoveDirection {
    Forward, Backward, Right, Left
}
