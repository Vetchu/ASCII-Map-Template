package agh.cs.lab1;

enum Direction{
    forward,right,back,left,incorrect
}