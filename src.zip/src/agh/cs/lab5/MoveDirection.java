package agh.cs.lab5;

enum MoveDirection {
    Forward, Backward, Right, Left
}
