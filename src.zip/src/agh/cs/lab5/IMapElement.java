package agh.cs.lab5;

public interface IMapElement {
    public String toString();
    public Position getPosition();
}
