package agh.cs.lab2;

public class CarSystem {

}
