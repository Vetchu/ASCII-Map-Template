package agh.cs.lab2;

enum MoveDirection {
    Forward, Backward, Right, Left
}
