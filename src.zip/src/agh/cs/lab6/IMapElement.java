package agh.cs.lab6;

public interface IMapElement {
    public String toString();
    public Position getPosition();
}
