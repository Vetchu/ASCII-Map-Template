package agh.cs.lab6;

enum MoveDirection {
    Forward, Backward, Right, Left
}
