package agh.cs.lab3;

enum MoveDirection {
    Forward, Backward, Right, Left
}
