package agh.cs.lab3;

import agh.cs.lab2.Position;
import org.junit.Test;

import static org.junit.Assert.*;

public class PositionTest {
    agh.cs.lab2.Position A = new agh.cs.lab2.Position(1, 2);

    @Test
    public void toStringTest() {
        assertEquals("(3,4)", new agh.cs.lab2.Position(3, 4).toString(), "(3,4)");
        assertEquals("(5,-1)", new agh.cs.lab2.Position(5, -1).toString(), "(5,-1)");
    }

    @Test
    public void smallerTest() {
        assertTrue("Pozycja 3,4 > 1,2", A.smaller(new agh.cs.lab2.Position(3, 4)));
        assertTrue("Pozycja 1,2 <=1,2", A.smaller(new agh.cs.lab2.Position(1, 2)));
        assertFalse("Pozycja 0,1 <=1,2", A.smaller(new agh.cs.lab2.Position(1, 1)));
    }

    @Test
    public void largerTest() {
        assertFalse("Pozycja 3,4 > 1,2", A.larger(new agh.cs.lab2.Position(3, 4)));
        assertTrue("Pozycja 1,2 <=1,2", A.larger(new agh.cs.lab2.Position(1, 2)));
        assertTrue("Pozycja 0,1 <=1,2", A.larger(new agh.cs.lab2.Position(1, 1)));
    }

    @Test
    public void lowerLeftTest() {
        assertEquals("Lewa Dolna Pozycja 3,3 i 1,2-> 1,2", A.lowerLeft(new agh.cs.lab2.Position(3, 3)), new agh.cs.lab2.Position(1, 2));
        assertEquals("Lewa Dolna Pozycja 2,1 i 1,2-> 1,1", A.lowerLeft(new agh.cs.lab2.Position(2, 1)), new agh.cs.lab2.Position(1, 1));
    }

    @Test
    public void upperRightTest() {
        assertEquals("Prawa Górna Pozycja 3,3 i 1,2-> 3,3", A.upperRight(new agh.cs.lab2.Position(3, 3)), new agh.cs.lab2.Position(3, 3));
        assertEquals("Prawa Górna Pozycja 2,1 i 1,2-> 2,2", A.upperRight(new agh.cs.lab2.Position(2, 1)), new agh.cs.lab2.Position(2, 2));
    }

    @Test
    public void add() {
        assertEquals("Pozycja plus 3,3 i 1,2-> 4,5", A.add(new agh.cs.lab2.Position(3, 3)), new agh.cs.lab2.Position(4, 5));
        assertEquals("Pozycja plus 2,1 i 1,2-> 3,3", A.add(new agh.cs.lab2.Position(2, 1)), new Position(3, 3));
    }
}